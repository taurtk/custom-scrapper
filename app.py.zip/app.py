import asyncio
from playwright.async_api import async_playwright
import re
import csv
import time
import sys

def extract_info(popup_text):
    try:
        # Clean the text first
        popup_text = re.sub(r"[\ue000-\uf8ff]", "", popup_text)  # Remove special Unicode chars
        
        # Remove common UI elements and section headers
        popup_text = re.sub(
            r"\b(?:See photos|Overview|Menu|Reviews|About|Directions|Save|Nearby|"
            r"Send to phone|Share|Popular times|Menu & highlights|Review summary|"
            r"Write a review|People also search for|Web results|About this data|"
            r"Closed ⋅ Opens|Reported by|Place an order|Suggest an edit|Updates from|"
            r"Popular|All|Latest|Videos|By owner|Street View|Add photos|Like|"
            r"Response from|Local Guide|Sort|More reviews|Website|Call|Hours|Services|"
            r"Service options|Amenities|Accessibility|Offerings|Dining options|"
            r"Crowd|Planning|Health and safety|Payments|Atmosphere|From the business)\b",
            "", 
            popup_text, 
            flags=re.IGNORECASE
        )
        
        # Split into lines and clean each line
        lines = [line.strip() for line in popup_text.split("\n") if line.strip()]
        lines = [line for line in lines if not re.match(r"^\W+$", line)]  # Remove lines with only symbols
        
        # Extract brand - take the first meaningful line that's not too short
        brand = "N/A"
        for line in lines:
            clean_line = re.sub(r"·.*", "", line).strip()  # Remove ratings and other metadata
            if len(clean_line) > 3 and not any(word in clean_line.lower() for word in ['photos', 'overview', 'menu', 'reviews', 'call']):
                brand = clean_line
                break
        
        # Improved email regex
        email = "N/A"
        email_match = re.search(
            r"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b",
            popup_text
        )
        if email_match:
            email = email_match.group()
        
        # Enhanced phone number extraction with multiple patterns
        phone = "N/A"
        phone_patterns = [
            r"(?:\+91[\s-]?)?[6-9]\d{2}[\s-]?\d{3}[\s-]?\d{4}",  # Standard Indian mobile
            r"\b0\d{2,4}[-.\s]?\d{6,8}\b",  # Landline numbers
            r"\b\d{4}[-.\s]?\d{3}[-.\s]?\d{3}\b",  # Alternative Indian mobile
            r"\(\d{3,4}\)\s*\d{3,4}[-.\s]?\d{4}",  # Numbers with area code
            r"\b\d{3,4}\s\d{3,4}\s\d{3,4}\b"  # Space-separated numbers
        ]
        
        for pattern in phone_patterns:
            matches = re.findall(pattern, popup_text)
            if matches:
                # Filter out numbers that are likely pincodes or years
                valid_numbers = [num for num in matches if not re.match(r"^\d{4,6}$", num)]
                if valid_numbers:
                    phone = valid_numbers[0]
                    # Clean the phone number
                    phone = re.sub(r"[^\d+]", "", phone)
                    if phone.startswith('0') and len(phone) == 11:
                        phone = '+91' + phone[1:]  # Convert to international format
                    break
        
        # Enhanced address extraction
        address = "N/A"
        # This regex matches typical Indian addresses, but is more general for global use
        address_patterns = [
            r"\d{1,4}[,\s]+[\w\s\-\.]+(?:road|street|avenue|block|main|rd|st|ave|nagar|layout|phase|circle|lane|cross|mg road|sector|plaza|market|complex|building|tower|floor|park|colony|society|enclave|extension|bypass|highway|boulevard|drive|path|walk|court|square|place|terrace|heights|residency|garden|estate|apartments|residences|house|plot|flat|suite|unit|room)[,\w\s\-\.]*,?\s*[\w\s\-\.]+,?\s*[A-Za-z ]+\s*\d{6,7}",
            r"[\w\s\-\.]+,?\s*[\w\s\-\.]+,?\s*[A-Za-z ]+\s*\d{6,7}",
            r"[\w\s\-\.]+,?\s*[\w\s\-\.]+,?\s*[A-Za-z ]+\s*\d{5,7}",
            r"[\w\s\-\.]+,?\s*[\w\s\-\.]+,?\s*[A-Za-z ]+"
        ]
        full_text = ' '.join(lines)
        for pattern in address_patterns:
            match = re.search(pattern, full_text, re.IGNORECASE)
            if match and len(match.group().strip()) > 10:
                address = match.group().strip()
                break
        
        # If no pattern match, look for address components
        if address == "N/A":
            address_lines = []
            for line in lines:
                if (re.search(r"\d{1,4}\s+\w+", line) and  # Contains number and street
                    any(word in line.lower() for word in ['road', 'st', 'rd', 'ave', 'nagar', 'layout', 'main', 'cross', 'mg road', 'block']) or
                    re.search(r"\b\d{6}\b", line)):  # Contains pincode
                    if len(line) > 5:  # Skip very short lines
                        address_lines.append(line)
            
            if address_lines:
                # Combine lines, removing duplicates
                unique_lines = []
                seen = set()
                for line in address_lines:
                    clean_line = re.sub(r"[^\w\s,-]", "", line).strip()
                    if clean_line not in seen:
                        seen.add(clean_line)
                        unique_lines.append(clean_line)
                
                address = ', '.join(unique_lines[:3])  # Combine up to 3 relevant lines
        
        # Owner name extraction with more context
        owner_first_name = "N/A"
        name_patterns = [
            r"(?:owner|contact|manager|proprietor|founder|director)[\s:/-]+([A-Z][a-z]+)",
            r"\b(?:mr|ms|mrs)\.?\s+([A-Z][a-z]+)\b",
            r"response from\s+([A-Z][a-z]+)",
            r"dear\s+([A-Z][a-z]+)\b",
            r"contact person\s*:\s*([A-Z][a-z]+)",
            r"managed by\s+([A-Z][a-z]+)",
            r"person in charge\s*:\s*([A-Z][a-z]+)"
        ]
        
        for pattern in name_patterns:
            try:
                match = re.search(pattern, popup_text, re.IGNORECASE)
                if match and match.group(1).lower() not in ['delivery', 'guest', 'customer', 'join', 'business']:
                    owner_first_name = match.group(1)
                    break
            except IndexError:
                continue
        
        # Final cleanup
        brand = re.sub(r"[^\w\s&'-]", "", brand).strip()
        address = re.sub(r"\b(?:dine-in|takeaway|no-contact delivery)\b", "", address, flags=re.IGNORECASE).strip()
        
        return {
            "brand": brand if brand != "N/A" and len(brand) > 2 else "N/A",
            "email": email,
            "phone": phone if phone != "N/A" and len(phone) >= 8 else "N/A",
            "address": address if address != "N/A" and len(address) > 10 else "N/A",
            "owner_first_name": owner_first_name if owner_first_name != "N/A" else "N/A"
        }
    except Exception as e:
        print(f"Error in extract_info: {e}")
        return {
            "brand": "N/A",
            "email": "N/A",
            "phone": "N/A",
            "address": "N/A",
            "owner_first_name": "N/A"
        }

async def scroll_google_maps_results(page, scrolls=10, delay=1):
    for _ in range(scrolls):
        await page.evaluate('''() => {
            const scrollable = document.querySelector('div[role="feed"]');
            if (scrollable) {
                scrollable.scrollBy(0, 1000);
            }
        }''')
        await page.wait_for_timeout(delay * 1000)

async def scrape_google_maps(search_query):
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context()
        page = await context.new_page()

        print(f"Navigating to Google Maps for: {search_query}")
        await page.goto(f"https://www.google.com/maps/search/{search_query.replace(' ', '+')}", timeout=60000)
        await page.wait_for_selector(".hfpxzc", timeout=10000)

        # Improved scrolling mechanism to load all cards
        print("Scrolling to load all restaurants...")
        last_card_count = 0
        current_card_count = 0
        scroll_attempts = 0
        max_scroll_attempts = 50  # Safety limit to prevent infinite scrolling
        
        # Pre-scroll the main page to the bottom to trigger lazy loading
        scroll_google_maps_results(page)

        while scroll_attempts < max_scroll_attempts:
            # Get current number of cards
            cards = await page.query_selector_all(".hfpxzc")
            current_card_count = len(cards)
            
            # Break if no new cards loaded after scrolling
            if current_card_count == last_card_count:
                scroll_attempts += 1
                if scroll_attempts > 5:  # Give up after 5 attempts with no new cards
                    break
            else:
                scroll_attempts = 0
                last_card_count = current_card_count
            
            # Scroll to the bottom of the results panel
            await page.evaluate('''() => {
                const resultsPanel = document.querySelector('.m6QErb.DxyBCb.kA9KIf.dS8AEf');
                if (resultsPanel) {
                    resultsPanel.scrollTop = resultsPanel.scrollHeight;
                }
            }''')
            
            # Wait for new cards to load
            await page.wait_for_timeout(3000)
            
            # Check for "Show more results" button and click it if present
            try:
                show_more_button = await page.query_selector('button.HlvSq')
                if show_more_button:
                    await show_more_button.click()
                    await page.wait_for_timeout(2000)
            except:
                pass

        print(f"Found {last_card_count} restaurants after scrolling")

        # First, scroll the main page to the end to trigger lazy loading
        await page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
        await page.wait_for_timeout(2000)

        # Now scroll the results panel as before
        last_count = 0
        max_attempts = 100  # Allow more attempts for deep scrolling
        attempts = 0
        while True:
            # Scroll the results panel by focusing and pressing PageDown
            await page.focus('.m6QErb')
            await page.keyboard.press('PageDown')
            await page.wait_for_timeout(1200)
            # Count the number of cards currently loaded
            cards_now = await page.query_selector_all('.hfpxzc')
            if len(cards_now) == last_count:
                attempts += 1
            else:
                attempts = 0  # Reset if new cards loaded
            last_count = len(cards_now)
            if attempts >= 10:  # Stop if no new cards after 10 scrolls
                print("No more new cards loaded after scrolling.")
                break
            if last_count >= 200:  # Safety limit for very large result sets
                print("Reached 200 cards, stopping scroll.")
                break

        # Wait for any additional cards to load
        await page.wait_for_timeout(4000)

        # Use the scroll_google_maps_results function before card extraction
        await scroll_google_maps_results(page, scrolls=30, delay=1)

        # Now start card extraction
        print(f"Scrolling complete. Starting card extraction...")
        cards = await page.query_selector_all(".hfpxzc")
        print(f"Found {len(cards)} places after scrolling.")
        
        extracted_data = []
        cards = await page.query_selector_all(".hfpxzc")
        print(f"Starting extraction for {len(cards)} restaurants")
        
        for idx, card in enumerate(cards):
            try:
                print(f"Processing restaurant {idx+1}/{len(cards)}")
                
                # Click the card using JavaScript to avoid Playwright click issues
                await page.evaluate('''(card) => {
                    card.scrollIntoView({behavior: 'smooth', block: 'center'});
                    card.click();
                }''', card)
                
                await page.wait_for_timeout(3000)  # Wait for popup to load

                # Extract brand (restaurant name) from h1.DUwDvf.lfPIob
                try:
                    brand_elem = await page.query_selector("h1.DUwDvf.lfPIob")
                    brand = (await brand_elem.inner_text()).strip() if brand_elem else "N/A"
                except:
                    brand = "N/A"

                # Extract all address/phone divs
                try:
                    info_divs = await page.query_selector_all("div.Io6YTe.fontBodyMedium.kR99db.fdkmkc")
                    address = "N/A"
                    phone = "N/A"
                    max_addr_len = 0
                    for div in info_divs:
                        text = (await div.text_content()).strip()
                        # If text contains digits and is longer than previous, treat as address
                        if any(char.isdigit() for char in text) and len(text) > max_addr_len:
                            address = text
                            max_addr_len = len(text)
                        # If text looks like a phone number
                        elif any(char.isdigit() for char in text) and len(text) <= 15:
                            phone = text
                except:
                    address = "N/A"
                    phone = "N/A"

                # Extract email (if present in popup text)
                try:
                    popup_text = await page.evaluate('''() => {
                        const popup = document.querySelector('div.bJzME.Hu9e2e.tTVLSc');
                        return popup ? popup.innerText : '';
                    }''')
                    email_match = re.search(r"[\w\.-]+@[\w\.-]+", popup_text)
                    email = email_match.group(0) if email_match else "N/A"
                except:
                    email = "N/A"

                # Extract owner's first name
                try:
                    owner_match = re.search(r"Owner[:\s]+([A-Za-z]+)", popup_text)
                    owner_first_name = owner_match.group(1) if owner_match else "N/A"
                except:
                    owner_first_name = "N/A"

                data = {
                    'brand': brand,
                    'email': email,
                    'phone': phone,
                    'address': address,
                    'owner_first_name': owner_first_name
                }

                extracted_data.append(data)
                print(f"Extracted: {data['brand']} | {data['phone']} | {data['address']}")

                # Close the popup before clicking the next one
                await page.keyboard.press("Escape")
                await page.wait_for_timeout(1500)
                
            except Exception as e:
                print(f"Error processing card {idx}: {e}")
                continue

        # Save to CSV
        filename = 'bangalore_restaurants_complete.csv'
        with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['brand', 'email', 'phone', 'address', 'owner_first_name']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for row in extracted_data:
                writer.writerow(row)

        print(f"\nScraping completed! Data saved to {filename}")
        await browser.close()

# Run the scraper
if __name__ == "__main__":
    if len(sys.argv) > 1:
        search_query = ' '.join(sys.argv[1:])
    else:
        search_query = input("Enter your Google Maps search query: ")
    asyncio.run(scrape_google_maps(search_query))